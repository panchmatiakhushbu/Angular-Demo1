import { Component, OnInit } from '@angular/core';
import * as AOS from 'aos';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {


  constructor() { }

  ngOnInit() {
    AOS.init({
      duration: 1200,
    })
  }

  /*Expert slider js start*/
  public expertslider ={
     autoplay:true,
     autoplaySpeed:2000,
     speed:600,
     slidesToShow:3,
     slidesToScroll:1,
     pauseOnHover:false,     
     pauseOnDotsHover:true,      
     draggable:true,
     arrows:true,     
     responsive: [
      {
        breakpoint: 991,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,          
          dots: true,   
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          dots: true, 
        }
      }    
    ]    
  };

  /*Expert slider js end*/

  /*Testnomial slider js start*/

    public testnomialslider ={
    autoplay:true,
    autoplaySpeed:2000,
    speed:600,
    slidesToShow:2,
    slidesToScroll:1,
    pauseOnHover:false,     
    pauseOnDotsHover:true,      
    draggable:true,
    arrows:false,
    dots:true,     
    responsive: [
     {
       breakpoint: 991,
       settings: {
         slidesToShow: 2,
         slidesToScroll: 1,          
         dots: true,   
       }
     },
     {
       breakpoint: 600,
       settings: {
         slidesToShow: 1,
         slidesToScroll: 1,
         dots: true, 
       }
     }    
   ]    
 };
  /*Testnomial slider js end*/

}
